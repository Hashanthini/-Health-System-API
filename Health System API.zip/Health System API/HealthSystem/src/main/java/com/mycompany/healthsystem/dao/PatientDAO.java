/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {
    private static List<Patient> patients = new ArrayList<>();

    static {
        patients.add(new Patient(1, "Cc", "Cc@example.com", "3 Cc St", "No major issues", "Stable"));
        patients.add(new Patient(2, "Dd", "Dd@example.com", "4 Dd St", "Hypertension", "Recovering"));
    }

    public List<Patient> getAllPatients() {
        return patients;
    }

    public Patient getPatientById(int id) {
        for (Patient patient : patients) {
            if (patient.getId() == id) {
                return patient;
            }
        }
        return null;
    }

    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    public void updatePatient(Patient updatedPatient) {
        for (int i = 0; i < patients.size(); i++) {
            Patient patient = patients.get(i);
            if (patient.getId() == updatedPatient.getId()) {
                patients.set(i, updatedPatient);
                return;
            }
        }
    }

    public void deletePatient(int id) {
        patients.removeIf(patient -> patient.getId() == id);
    }
}


