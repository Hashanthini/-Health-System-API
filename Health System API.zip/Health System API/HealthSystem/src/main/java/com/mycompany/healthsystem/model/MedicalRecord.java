/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.model;

/**
 *
 * @author Hashanthini
 */

public class MedicalRecord {
    private int id;
    private Patient patient;
    private String diagnosis;
    private String treatment;

    public MedicalRecord(int id, Patient patient, String diagnosis, String treatment) {
        this.id = id;
        this.patient = patient;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
    }

    // Getter for id
    public int getId() {
        return id;
    }

    // Setter for id
    public void setId(int id) {
        this.id = id;
    }

    // Getter for patient
    public Patient getPatient() {
        return patient;
    }

    // Setter for patient
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    // Getter for diagnosis
    public String getDiagnosis() {
        return diagnosis;
    }

    // Setter for diagnosis
    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    // Getter for treatment
    public String getTreatment() {
        return treatment;
    }

    // Setter for treatment
    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }
}

