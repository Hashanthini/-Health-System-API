/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.resource;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.dao.PersonDAO;
import com.mycompany.healthsystem.model.Person;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/persons")
public class PersonResource {
    private PersonDAO personDAO = new PersonDAO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Person> getAllPersons() {
        return personDAO.getAllPersons();
    }

    @GET
    @Path("/{personId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getPersonById(@PathParam("personId") int personId) {
        return personDAO.getPersonById(personId);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addPerson(Person person) {
        personDAO.addPerson(person);
    }

    @PUT
    @Path("/{personId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updatePerson(@PathParam("personId") int personId, Person updatedPerson) {
        Person existingPerson = personDAO.getPersonById(personId);

        if (existingPerson != null) {
            updatedPerson.setId(personId);
            personDAO.updatePerson(updatedPerson);
        }
    }

    @DELETE
    @Path("/{personId}")
    public void deletePerson(@PathParam("personId") int personId) {
        personDAO.deletePerson(personId);
    }
}
