/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.MedicalRecord;
import com.mycompany.healthsystem.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {
    private static List<MedicalRecord> medicalRecords = new ArrayList<>();

    static {
        // Initialize some sample medical records
        Patient patient1 = new Patient(1, "Cc", "Cc@example.com", "3 Cc St", "No major issues", "Stable");
        medicalRecords.add(new MedicalRecord(1, patient1, "Fever", "Prescribed rest and medication"));

        Patient patient2 = new Patient(2, "Dd", "Dd@example.com", "4 Dd St", "Hypertension", "Recovering");
        medicalRecords.add(new MedicalRecord(2, patient2, "Hypertension", "Prescribed medication and lifestyle changes"));
        // Add more medical records as needed
    }

    public List<MedicalRecord> getAllMedicalRecords() {
        return medicalRecords;
    }

    public MedicalRecord getMedicalRecordById(int id) {
        for (MedicalRecord medicalRecord : medicalRecords) {
            if (medicalRecord.getId() == id) {
                return medicalRecord;
            }
        }
        return null;
    }

    public void addMedicalRecord(MedicalRecord medicalRecord) {
        medicalRecords.add(medicalRecord);
    }

    public void updateMedicalRecord(MedicalRecord updatedMedicalRecord) {
        for (int i = 0; i < medicalRecords.size(); i++) {
            MedicalRecord medicalRecord = medicalRecords.get(i);
            if (medicalRecord.getId() == updatedMedicalRecord.getId()) {
                medicalRecords.set(i, updatedMedicalRecord);
                return;
            }
        }
    }

    public void deleteMedicalRecord(int id) {
        medicalRecords.removeIf(medicalRecord -> medicalRecord.getId() == id);
    }
}


