/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.Billing;
import com.mycompany.healthsystem.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class BillingDAO {
    private static List<Billing> billings = new ArrayList<>();

    static {
        // Initialize some sample billings
        Patient patient1 = new Patient(1, "Cc", "Cc@example.com", "3 Cc St", "No major issues", "Stable");
        billings.add(new Billing(1, patient1, 100.0, false));

        Patient patient2 = new Patient(2, "Dd", "Dd@example.com", "4 Dd St", "Hypertension", "Recovering");
        billings.add(new Billing(2, patient2, 200.0, true));
        // Add more billings as needed
    }

    public List<Billing> getAllBillings() {
        return billings;
    }

    public Billing getBillingById(int id) {
        for (Billing billing : billings) {
            if (billing.getId() == id) {
                return billing;
            }
        }
        return null;
    }

    public void addBilling(Billing billing) {
        billings.add(billing);
    }

    public void updateBilling(Billing updatedBilling) {
        for (int i = 0; i < billings.size(); i++) {
            Billing billing = billings.get(i);
            if (billing.getId() == updatedBilling.getId()) {
                billings.set(i, updatedBilling);
                return;
            }
        }
    }

    public void deleteBilling(int id) {
        billings.removeIf(billing -> billing.getId() == id);
    }
}

