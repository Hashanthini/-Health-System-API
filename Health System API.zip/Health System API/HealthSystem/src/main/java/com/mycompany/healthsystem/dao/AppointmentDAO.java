/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.Appointment;
import com.mycompany.healthsystem.model.Doctor;
import com.mycompany.healthsystem.model.Patient;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    private static List<Appointment> appointments = new ArrayList<>();

    static {
        Doctor doctor1 = new Doctor(1, "Aa", "Aa@example.com", "1 Aa St", "Cardiologist");
        Patient patient1 = new Patient(1, "Cc", "Cc@example.com", "3 Cc St", "No major issues", "Stable");
        appointments.add(new Appointment(1, "2024-05-05", "05:00", patient1, doctor1));

        Doctor doctor2 = new Doctor(2, "Bb", "Bb@example.com", "2 Bb St", "Pediatrician");
        Patient patient2 = new Patient(2, "Dd", "Dd@example.com", "4 Dd St", "Hypertension", "Recovering");
        appointments.add(new Appointment(2, "2024-06-06", "06:00", patient2, doctor2));
    }

    public List<Appointment> getAllAppointments() {
        return appointments;
    }

    public Appointment getAppointmentById(int id) {
        for (Appointment appointment : appointments) {
            if (appointment.getId() == id) {
                return appointment;
            }
        }
        return null;
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public void updateAppointment(Appointment updatedAppointment) {
        for (int i = 0; i < appointments.size(); i++) {
            Appointment appointment = appointments.get(i);
            if (appointment.getId() == updatedAppointment.getId()) {
                appointments.set(i, updatedAppointment);
                return;
            }
        }
    }

    public void deleteAppointment(int id) {
        appointments.removeIf(appointment -> appointment.getId() == id);
    }
}
