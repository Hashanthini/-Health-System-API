/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.Person;
import java.util.ArrayList;
import java.util.List;

public class PersonDAO {
    private static List<Person> persons = new ArrayList<>();

    static {
        persons.add(new Person(1, "Aa", "Aa@example.com", "1 Aa St"));
        persons.add(new Person(2, "Bb", "Bb@example.com", "2 Bb St"));
        persons.add(new Person(3, "Cc", "Cc@example.com", "3 Cc St"));
        persons.add(new Person(4, "Dd", "Dd@example.com", "4 Dd St"));
    }

    public List<Person> getAllPersons() {
        return persons;
    }

    public Person getPersonById(int id) {
        for (Person person : persons) {
            if (person.getId() == id) {
                return person;
            }
        }
        return null;
    }

    public void addPerson(Person person) {
        persons.add(person);
    }

    public void updatePerson(Person updatedPerson) {
        for (int i = 0; i < persons.size(); i++) {
            Person person = persons.get(i);
            if (person.getId() == updatedPerson.getId()) {
                persons.set(i, updatedPerson);
                return;
            }
        }
    }

    public void deletePerson(int id) {
        persons.removeIf(person -> person.getId() == id);
    }
}

