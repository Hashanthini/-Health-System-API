/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthsystem.dao;

/**
 *
 * @author Hashanthini
 */

import com.mycompany.healthsystem.model.Patient;
import com.mycompany.healthsystem.model.Prescription;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionDAO {
    private static List<Prescription> prescriptions = new ArrayList<>();

    static {
        // Initialize some sample prescriptions
        Patient patient1 = new Patient(1, "Cc", "Cc@example.com", "3 Cc St", "No major issues", "Stable");
        prescriptions.add(new Prescription(1, patient1, "Aspirin", "500 mg", "Take one tablet daily", "2 weeks"));

        Patient patient2 = new Patient(2, "Dd", "Dd@example.com", "4 Dd St", "Hypertension", "Recovering");
        prescriptions.add(new Prescription(2, patient2, "Lisinopril", "10 mg", "Take one tablet daily with food", "1 month"));
        // Add more prescriptions as needed
    }

    public List<Prescription> getAllPrescriptions() {
        return prescriptions;
    }

    public Prescription getPrescriptionById(int id) {
        for (Prescription prescription : prescriptions) {
            if (prescription.getId() == id) {
                return prescription;
            }
        }
        return null;
    }

    public void addPrescription(Prescription prescription) {
        prescriptions.add(prescription);
    }

    public void updatePrescription(Prescription updatedPrescription) {
        for (int i = 0; i < prescriptions.size(); i++) {
            Prescription prescription = prescriptions.get(i);
            if (prescription.getId() == updatedPrescription.getId()) {
                prescriptions.set(i, updatedPrescription);
                return;
            }
        }
    }

    public void deletePrescription(int id) {
        prescriptions.removeIf(prescription -> prescription.getId() == id);
    }
}

